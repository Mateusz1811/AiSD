﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Huffman
{
    internal class HufmanTree
    {
        private Node root;

        private Dictionary<char, int> ObliczCzestosc(string input)
        {
            var czestosc = new Dictionary<char, int>();
            foreach (char c in input)
            {
                if (!czestosc.ContainsKey(c))
                    czestosc[c] = 0;
                czestosc[c]++;
            }
            return czestosc;
        }

        public void zbuduj(string input)
        {
            var czestosc = ObliczCzestosc(input);
            var priorytet = new PriorityQueue<Node, int>();

            foreach(var kvp  in czestosc)
            {
                priorytet.Enqueue(new Node (kvp.Key, kvp.Value), kvp.Value);
            }

            while(priorytet.Count > 1)
            {
                var lewo = priorytet.Dequeue();
                var prawo = priorytet.Dequeue();
                var rodzic = new Node(null, lewo.Czestosc + prawo.Czestosc)
                {
                    Lewo = lewo,
                    Prawo = prawo,
                };
                priorytet.Enqueue(rodzic, rodzic.Czestosc);
            }
            root = priorytet.Dequeue() ;
        }

        public Dictionary<char, string> generujKody()
        {
            var kody = new Dictionary<char, string>();
            generujKodyRekurencynie(root, "", kody);
            return kody;
        }

        private void generujKodyRekurencynie(Node node, string kod, Dictionary<char, string> kody)
        {
            if (node == null)
                return;

            if(node.Lewo == null && node.Prawo == null && node.Slowo.HasValue)
            {
                kody[node.Slowo.Value] = kod;
            }

            generujKodyRekurencynie(node.Lewo, kod + "0", kody);
            generujKodyRekurencynie(node.Prawo, kod + "1", kody);
        }

        public String zakoduj(string input, Dictionary<char, string> kody)
        {
            var sb = new StringBuilder();
            foreach(char c in input)
            {
                sb.Append(kody[c]);
            }
            return sb.ToString();
        }

        
    }
}
