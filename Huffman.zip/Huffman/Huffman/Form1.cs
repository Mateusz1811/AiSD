using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Huffman
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string input = textBox1.Text;
            if(string.IsNullOrEmpty(input))
            {
                MessageBox.Show("Wprowadz tekst do zakodowania");
                return;
            }

            var drzewoHuffmana = new HufmanTree();
            drzewoHuffmana.zbuduj(input);

            var kodyHufmana = drzewoHuffmana.generujKody();

            string zakodowanyText = drzewoHuffmana.zakoduj(input, kodyHufmana);

            textBox2.Text = zakodowanyText;
            listBox1.Items.Clear();
            foreach(var kvp in kodyHufmana)
            {
                listBox1.Items.Add($"'{kvp.Key}' : {kvp.Value}");
            }



        }
    }
}
