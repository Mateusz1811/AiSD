﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Huffman
{
    internal class Node
    {
        public char? Slowo { get; set; }
        public int Czestosc { get; set; }
        public Node Lewo {  get; set; }
        public Node Prawo {  get; set; }

        public Node(char? slowo, int czestosc)
        {
            Slowo = slowo;
            Czestosc = czestosc;
            Lewo = null;
            Prawo = null;
        }
    }
}
