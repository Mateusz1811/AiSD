﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace algorytymDjikstry
{
    internal class Graf
    {
        private Dictionary<int, List<Edge>> adjacencyList;

        public Graf()
        {
            adjacencyList = new Dictionary<int, List<Edge>>();
        }

        public void AddEdge(int from, int to, int weight)
        {
            if (!adjacencyList.ContainsKey(from))
            {
                adjacencyList[from] = new List<Edge>();
            }

            adjacencyList[from].Add(new Edge(to, weight));


            if (!adjacencyList.ContainsKey(to))
            {
                adjacencyList[to] = new List<Edge>();
            }
        }

 
        public void ShowGraph()
        {
            foreach (var node in adjacencyList)
            {
                Console.Write($"Node {node.Key}: ");
                foreach (var edge in node.Value)
                {
                    Console.Write($" -> {edge.To} (Weight: {edge.Weight})");
                }
                Console.WriteLine();
            }
        }

        public (Dictionary<int, int> distances, Dictionary<int, int?> previousNodes) Dijkstra(int startNode)
        {
            var distances = new Dictionary<int, int>();
            var previousNodes = new Dictionary<int, int?>();
            var priorityQueue = new SortedSet<(int distance, int node)>();


            foreach (var node in adjacencyList.Keys)
            {
                distances[node] = int.MaxValue;
                previousNodes[node] = null;  
            }

            distances[startNode] = 0;
            priorityQueue.Add((0, startNode));

            while (priorityQueue.Any())
            {

                var (currentDistance, currentNode) = priorityQueue.First();
                priorityQueue.Remove(priorityQueue.First());


                foreach (var edge in adjacencyList[currentNode])
                {
                    int newDistance = currentDistance + edge.Weight;

                    if (newDistance < distances[edge.To])
                    {

                        priorityQueue.Remove((distances[edge.To], edge.To));
                        distances[edge.To] = newDistance;
                        previousNodes[edge.To] = currentNode;
                        priorityQueue.Add((newDistance, edge.To));
                    }
                }
            }

            return (distances, previousNodes);
        }
    }
}
