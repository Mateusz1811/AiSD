﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace algorytymDjikstry
{
    internal class Graf
    {
        private Dictionary<int, List<Edge>> adjacencyList;

        public Graf()
        {
            adjacencyList = new Dictionary<int, List<Edge>>();
        }

        // Method to add an edge to the graph
        public void AddEdge(int from, int to, int weight)
        {
            if (!adjacencyList.ContainsKey(from))
            {
                adjacencyList[from] = new List<Edge>();
            }

            adjacencyList[from].Add(new Edge(to, weight));

            // Ensure the "to" node exists in the adjacency list (even if it has no outgoing edges)
            if (!adjacencyList.ContainsKey(to))
            {
                adjacencyList[to] = new List<Edge>();
            }
        }

        // Method to show the graph structure
        public void ShowGraph()
        {
            foreach (var node in adjacencyList)
            {
                Console.Write($"Node {node.Key}: ");
                foreach (var edge in node.Value)
                {
                    Console.Write($" -> {edge.To} (Weight: {edge.Weight})");
                }
                Console.WriteLine();
            }
        }

        // Dijkstra's Algorithm
        public (Dictionary<int, int> distances, Dictionary<int, int?> previousNodes) Dijkstra(int startNode)
        {
            var distances = new Dictionary<int, int>();
            var previousNodes = new Dictionary<int, int?>();
            var priorityQueue = new SortedSet<(int distance, int node)>();

            // Initialize distances and priority queue
            foreach (var node in adjacencyList.Keys)
            {
                distances[node] = int.MaxValue; // Infinite distance
                previousNodes[node] = null;    // No previous node
            }

            distances[startNode] = 0;
            priorityQueue.Add((0, startNode));

            while (priorityQueue.Any())
            {
                // Extract node with smallest distance
                var (currentDistance, currentNode) = priorityQueue.First();
                priorityQueue.Remove(priorityQueue.First());

                // Update neighbors
                foreach (var edge in adjacencyList[currentNode])
                {
                    int newDistance = currentDistance + edge.Weight;

                    if (newDistance < distances[edge.To])
                    {
                        // Update the distance
                        priorityQueue.Remove((distances[edge.To], edge.To));
                        distances[edge.To] = newDistance;
                        previousNodes[edge.To] = currentNode;
                        priorityQueue.Add((newDistance, edge.To));
                    }
                }
            }

            return (distances, previousNodes);
        }
    }
}
