﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace algorytymDjikstry
{
    internal class Edge
    {
        public int To { get; }
        public int Weight { get; }

        public Edge(int to, int weight)
        {
            To = to;
            Weight = weight;
        }
    }
}
