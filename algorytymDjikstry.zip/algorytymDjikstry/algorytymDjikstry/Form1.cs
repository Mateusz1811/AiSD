﻿namespace algorytymDjikstry
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Text = "Windows Forms - Algorytm Dijkstry";

            // Przyciski i pola tekstowe do wizualizacji
            var buttonRun = new Button
            {
                Text = "Uruchom Dijkstrę",
                Width = 150,
                Height = 30,
                Top = 20,
                Left = 20
            };
            buttonRun.Click += Form1_Load;

            this.Controls.Add(buttonRun);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Przykład użycia klasy Graph i wizualizacja wyników
            var graph = new Graf();
            graph.AddEdge(0, 1, 3);
            graph.AddEdge(0, 2, 2);
            graph.AddEdge(1, 3, 3);
            graph.AddEdge(1, 4, 6);
            graph.AddEdge(2, 1, 1);
            graph.AddEdge(2, 5, 4);
            graph.AddEdge(3, 5, 2);
            graph.AddEdge(4, 5, 1);

            int startNode = 0;
            var (distances, previousNodes) = graph.Dijkstra(startNode);

            // Wyświetlenie wyników w oknie dialogowym
            string result = "Najkrótsze odległości:\n";
            foreach (var kvp in distances)
            {
                result += $"Node {kvp.Key}: Distance = {kvp.Value}\n";
            }

            MessageBox.Show(result, "Wyniki Dijkstry");

        }
    }
}
