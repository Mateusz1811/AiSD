﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Listy21102024
{
    internal class ListL
    {
        public Node Head;
        public Node Tail;
        public int Count;

        public void AddFirst(int data)
        {

            Node newNode = new Node(data);

            if (Head == null)
            {
                Head = Tail = newNode;
            }
            else
            {
                newNode.Next = Head;
                Head.Prev = newNode;
                Head = newNode;
            }
            Count++;
        }

        public void AddLast(int data)
        {
            Node newNode = new Node(data);
            if (Tail == null)
            {
                Head = Tail = newNode;
            }
            else
            {
                newNode.Prev = Tail;
                Tail.Next = newNode;
                Tail = newNode;
            }
            Count++;

        }

        public void RemoveFirst()
        {
            if (Head == null) return;

            if (Head == Tail)
            {
                Head = Tail = null;
            }
            else
            {
                Head = Head.Next;
                Head.Prev = null;
            }
            Count--;


        }

        public void RemoveLast()
        {
            if (Tail == null) return;

            if (Head == Tail)
            {
                Head = Tail = null;
            }
            else
            {
                Tail = Tail.Prev;
                Tail.Next = null;
            }
            Count--;
        }

        
        public override string ToString()
        {
            var result = new System.Text.StringBuilder();
            var current = Head;

            while (current != null)
            {
                result.Append(current.Data + " ");
                current = current.Next;
            }

            return result.ToString();
        }
    }
}
