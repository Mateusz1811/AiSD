using System.Collections.Generic;
using System.Xml.Linq;

namespace Listy21102024
{
    public partial class Form1 : Form
    {
        private ListL list;
        public Form1()
        {
            InitializeComponent();
            list = new ListL();

        }

        private void UpdateListDisplay()
        {
            label1.Text = "List: " + list.ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out int data))
            {
                list.AddFirst(data);
                UpdateListDisplay();
                textBox1.Clear();
            }
            else
            {
                MessageBox.Show("Please enter a valid integer.");
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out int data))
            {
                list.AddLast(data);
                UpdateListDisplay();
                textBox1.Clear();
            }
            else
            {
                MessageBox.Show("Please enter a valid integer.");
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            list.RemoveFirst();
            UpdateListDisplay();


        }

        private void button4_Click(object sender, EventArgs e)
        {
            list.RemoveLast();
            UpdateListDisplay();

        }


        

    }

    
}

