﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Listy21102024;

namespace Listy21102024
{
    internal class BST
    {
        public NodeT root;


        public void Add(int liczba)
        {
            NodeT newNode = new NodeT(liczba);

            if (root == null)
            {
                root = newNode;
                return;
            }

            NodeT current = root;
            NodeT rodzic = null;

            while (current != null)
            {
                rodzic = current;
                if (liczba < current.data)
                {
                    current = current.lewa;
                    if (current == null)
                    {
                        rodzic.lewa = newNode;
                        newNode.rodzic = rodzic;
                        return;
                    }
                }
                else
                {
                    current = current.prawa;
                    if (current == null)
                    {
                        rodzic.prawa = newNode;
                        newNode.rodzic = rodzic;
                        return;
                    }
                }
            }
        }

        public void AddNaCw(int liczba)
        {
            var dziecko = new NodeT(liczba);
            if (this.root == null)
            {
                this.root = dziecko;
                return;
            }

            var rodzic = this.SzukajRodzica(dziecko);

            dziecko.rodzic = rodzic;
            if (rodzic.data > dziecko.data)
            {
                rodzic.lewa = dziecko;
            }
            else
            {
                rodzic.prawa = dziecko;
            }
        }

        public NodeT SzukajRodzica(NodeT dziecko)
        {
            var tmp = this.root;
            while (true)
            {
                if (tmp.data > dziecko.data)
                {
                    if (tmp.lewa == null)
                    {
                        return tmp;
                    }
                    else
                    {
                        tmp = tmp.lewa;
                    }
                }
                else
                {
                    tmp = tmp.prawa;
                }
            }

            
        }

        public void CPD(NodeT wezel)
        {
            if(wezel == null)
            {
                return;
            }
            CPD(wezel.lewa);
            CPD(wezel.prawa);

        }

        public void PreOrder(NodeT wezel)
        {
            if(wezel==null)
            {
                return;
            }

            Console.Write(wezel.data + " ");
            PreOrder(wezel.lewa);
            PreOrder(wezel.prawa);
        }

        public void InOrder(NodeT wezel)
        {
            if (wezel == null)
                return;

            InOrder(wezel.lewa);
            Console.Write(wezel.data + " ");
            InOrder(wezel.prawa);
        }

        public void PostOrder(NodeT wezel)
        {
            if (wezel == null)
                return;

            PostOrder(wezel.lewa);
            PostOrder(wezel.prawa);
            Console.Write(wezel.data + " ");
        }

        public NodeT RemoveElement1(NodeT n)
        {
            NodeT dziecko = null;
            if(n.lewa != null)
            {
                dziecko = n.lewa;
                this.RemoveElement0(dziecko);
            }
            else if(n.prawa != null)
            {
                dziecko = n.prawa;
                this.RemoveElement0(dziecko);

            }
            return dziecko;
        }



        public void RemoveElement0(NodeT n)
        {
            if(this.root == n)
            {
                this.root = null;
            }
            else
            {
                if(n.rodzic.lewa == n)
                {
                    n.rodzic.lewa = null;
                }
                else if(n.rodzic.prawa == n)
                {
                    n.rodzic.prawa = null;
                }
                n.rodzic = null;
            }
            
        }

        public NodeT Min(NodeT n)
        {
            var tmp = n;
            while (tmp.lewa != null)
            {
                tmp = tmp.lewa;
            }
            return tmp;
        }

        public void RemoveElement(NodeT n)
        {
            if(n.liczbaDzieci()==2)
            {
                var tmp = this.Min(n.prawa);
                var dziecko = this.RemoveElement1(tmp);
                var rodzic = tmp.rodzic;
                this.RemoveElement0(tmp);
                if (rodzic != n)
                {
                    rodzic.PolaczLewe(dziecko);
                }
                else
                {
                    rodzic.PolaczPrawe(dziecko);
                }
                tmp.rodzic = n.rodzic;
                n.rodzic = null;
                tmp.lewa = n.lewa;
                n.lewa = null;
                tmp.prawa = n.prawa;
                n.prawa = null;
            }
        }

        
        
    }
}


