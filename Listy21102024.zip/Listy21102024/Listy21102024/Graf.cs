﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Listy21102024
{
    internal class Graf
    {
        public List<NodeG> nodes = new List<NodeG>();

        public List<NodeG>Wszerz(NodeG start)
        {
            List<NodeG> odwiedzone = new List<NodeG>() { start };
            for(int i = 0; i < odwiedzone.Count; i++)
            {
                var tmp = odwiedzone[i];
                for(int j = 0; j < tmp.sąsiedzi.Count; j++)
                {
                    if (!odwiedzone.Contains(tmp.sąsiedzi[j]))
                    {
                        odwiedzone.Add(tmp.sąsiedzi[j]);
                    }
                }
                
            }
            return odwiedzone;

        }


    }
}
