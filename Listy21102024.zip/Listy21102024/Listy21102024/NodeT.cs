﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Listy21102024
{
    internal class NodeT
    {
        public NodeT rodzic;
        public NodeT lewa;
        public NodeT prawa;
        public int data;

        public NodeT(int liczba)
        {
            this.data = liczba;

        }

        public int liczbaDzieci()
        {
            int wynik = 0;
            if(this.lewa != null)
            {
                wynik++;
            }
            if(this.prawa != null) 
            {
                wynik++;
            }
            return wynik;
        }

        public void PolaczLewe(NodeT dziecko)
        {
            this.lewa = dziecko;
            if(dziecko != null)
            {
                dziecko.rodzic = this;
            }
        }

        public void PolaczPrawe(NodeT dziecko)
        {
            this.prawa = dziecko;
            if(dziecko != null)
            {
                dziecko.rodzic = this;
            }
        }



        public override string ToString()
        {
            return this.data.ToString();
        }

    }
}
