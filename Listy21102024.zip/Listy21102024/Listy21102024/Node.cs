﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Listy21102024
{
    internal class Node
    {
        public Node Next;
        public Node Prev;
        public int Data;

        public Node(int data)
        {
            Data = data;
        }
        
    }
}
