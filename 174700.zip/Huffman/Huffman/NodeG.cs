﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Huffman
{
    internal class NodeG
    {
        public NodeG lewe;
        public NodeG prawe;
        public NodeG rodzic;
        public int data;

        ///OrderBy(n = > n.data);
        ///ThenBy(n = > n.getType()==typeof(NodeGs)?0:1)
    }
}
