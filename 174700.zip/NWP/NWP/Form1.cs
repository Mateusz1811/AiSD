namespace NWP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string napis1 = textBox1.Text;
            string napis2 =  textBox2.Text;

     
            static string lcs(string napis1, string napis2)
            {
                int n = napis1.Length;
                int m = napis2.Length;


                int[,] tab = new int[n + 1 , m + 1];

                for (int i = 1; i <= n; i++)
                {
                    for (int j = 1; j <= m; j++)
                    {

                        if (napis1[i - 1] == napis2[j - 1])
                        {
                            tab[i, j] = tab[i - 1, j - 1] + 1;
                        }
                        else
                        {
                            tab[i, j] = Math.Max(tab[i - 1, j], tab[i, j - 1]);
                        }

                    }
                }

                int x = n, y = m;
                string result = "";

                while(x>0 && y>0)
                {
                    if (napis1[x-1] == napis2[y - 1])
                    {
                        result = napis1[x - 1] + result;
                        x--;
                        y--;
                    }
                    else if (tab[x-1,y] > tab[x,y-1])
                    {
                        x--;
                    }
                    else
                    {
                        y--;
                    }
                }

                return result;



                

            }


            int dlugosc = lcs(napis1, napis2).Length;

            MessageBox.Show(dlugosc.ToString());
            
         
        }
    }
}