﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace grafy
{
    internal class Graf1
    {
        public List<NodeG1> nodes = new List<NodeG1>();
        public List<Edge> edges = new List<Edge>();
        public Graf1(Edge k)
        {

        }

        public int ileNowychWezlow(Edge k)
        {

        }

        public void Add(Edge k)
        {

        }

        public void Join(Graf1 g1)
        {

        }

        List<Graf1>;

    }
}
