﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grafy
{
    internal class NodeG
    {
        public int data;
        public List<NodeG> sasiedzi;
        public Point pozycja;

        public NodeG(int data, Point pozycja)
        {
            this.data = data;
            this.sasiedzi = new List<NodeG>();
            this.pozycja = pozycja;
        }
    }
}
