namespace Grafy
{
    public partial class Form1 : Form
    {
        private Graf graf;
        public Form1()
        {
            InitializeComponent();
            this.graf = new Graf();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            var A = new NodeG(1, new Point(100, 200));
            var B = new NodeG(2, new Point(200, 100));
            var C = new NodeG(3, new Point(100, 400));
            var D = new NodeG(4, new Point(300, 200));
            var E = new NodeG(5, new Point(400, 100));
            var F = new NodeG(6, new Point(400, 300));
            var G = new NodeG(7, new Point(500, 400));

            this.graf.AddNode(A);
            this.graf.AddNode(B);
            this.graf.AddNode(C);
            this.graf.AddNode(D);
            this.graf.AddNode(E);
            this.graf.AddNode(F);
            this.graf.AddNode(G);

            this.graf.AddEdge(A, B);
            this.graf.AddEdge(A, D);
            this.graf.AddEdge(B, E);
            this.graf.AddEdge(C, A);
            this.graf.AddEdge(D, F);
            this.graf.AddEdge(E, F);
            this.graf.AddEdge(F, G);

            this.Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            this.graf.DrawGraph(e.Graphics);
        }
    }
    
}
